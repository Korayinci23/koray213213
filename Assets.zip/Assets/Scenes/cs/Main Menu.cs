using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void PlayCampaing()
    {
        SceneManager.LoadScene("Campaing");
    }
    public void QuitGame()
    {
        Application.Quit();
    }
    public void GoHangar()
    {
        SceneManager.LoadScene("Hangar");
    }
    public void back()
    {
        SceneManager.LoadScene("Main_menu");
    }
    public void GoSettings()
    {
        SceneManager.LoadScene("Settings_menu");
    }
    public void GoExtras()
    {
        SceneManager.LoadScene("Extras");
    }
}